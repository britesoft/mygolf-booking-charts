import { Component, ViewChild, ElementRef, OnInit } from "@angular/core";
import { Chart } from "chart.js";

@Component({
  selector: "app-home",
  templateUrl: "home.page.html",
  styleUrls: ["home.page.scss"],
})
export class HomePage implements OnInit {
  @ViewChild("barCanvas", { static: true }) barCanvas: ElementRef;
  @ViewChild("booking", { static: true }) doughnutCanvas: ElementRef;
  @ViewChild("totalPax", { static: true }) totalPax: ElementRef;
  @ViewChild("courses", { static: true }) courses: ElementRef;
  @ViewChild("caddies", { static: true }) caddies: ElementRef;
  public barChart: Chart;
  public bookingchart: Chart;
  public Pax: Chart;
  public coursesCharts: Chart;
  public caddiesChart: Chart;
  type: any = "line";
  lessThanOrGreaterThan = "lessThan";
  filterLimit = 100;
  thisweek: any = [];
  chartData = {
    dataSet1: Array.from(
      { length: 8 },
      () => Math.floor(Math.random() * 590) + 10
    ),
    // "dataSet2" : Array.from({ length: 8 }, () => Math.floor(Math.random() * 590) + 10)
  };
  levelsArr = [
    "Jan",
    "Feb",
    "Mar",
    "April",
    "May",
    "June",
    "July",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  months = [
    { month: "Jan", value: "0" },
    { month: "Feb", value: "1" },
    { month: "Mar", value: "2" },
    { month: "Apr", value: "3" },
    { month: "May", value: "4" },
    { month: "Jun", value: "5" },
    { month: "Jul", value: "6" },
    { month: "Aug", value: "7" },
    { month: "Sep", value: "8" },
    { month: "Oct", value: "9" },
    { month: "Nov", value: "10" },
    { month: "Dec", value: "11" },
  ];

  from = "0";

  toMonth = "12";
  doughnutChart: any;

  constructor() {}

  ngOnInit() {
    this.createtotalpaxChart();
    this.bookingChart();
    this.createChart();
    this.createCoursesChart();
    this.createCaddiesChart();
  }
createtotalpaxChart(){
  this.Pax = new Chart(this.totalPax.nativeElement, {
    type:  this.type,
    options: {
      responsive: true,
      maintainAspectRatio: true,
      title: {
        display: true,
        text: "Club Total Pax",
      },
      scales: {
        yAxes: [{
          display: true,
          scaleLabel: {
            display: true,
            // labelString: 'Score'
          },
          ticks: {
            min: 0,
            stepSize: 100
          }
        }]
      },
    },
    data: { labels: [
      'Total Pax', 'Total Pending','Total Checked In','Total In-Play',' Total Total Finish'
    ],
      datasets: [
        {
          fill: true,
          type: this.type,
          label: "Pax",
          data:[400, 300, 100, 40, 10],
          backgroundColor: [
            "rgba(153, 102, 255, 0.8)",
            "rgba(255, 99, 132, 0.8)",
            "rgba(54, 162, 235, 0.8)",
            "rgba(255, 206, 86, 0.8)",
            "rgba(75, 192, 192, 0.8)",
          ],
          spanGaps: true,
        },
      ],
    },
  });
}

createCaddiesChart(){
  this.caddiesChart = new Chart(this.caddies.nativeElement, {
    type:  this.type,
    options: {
      responsive: true,
      maintainAspectRatio: true,
      aspectRatio: 2,
      title: {
        display: true,
        text: "Caddies Overview",
      },
      scales: {
        // yAxes: [
        //   {
        //     ticks: {
        //       beginAtZero: true,
        //     },
        //   },
        // ],
        yAxes: [{
          display: true,
          scaleLabel: {
            display: true,
            // labelString: 'Score'
          },
          ticks: {
            min: 0,
            stepSize: 50
          }
        }]
      },
    },
    data: { labels: [
      'Male', 'Female','Total Caddies'
    ],
      datasets: [
        {
          fill: true,
          type: this.type,
          label: "Caddies",
          data:[170, 30, 200],
          backgroundColor: [
            "rgba(153, 102, 255, 0.8)",
            "rgba(255, 99, 132, 0.8)",
            "rgba(54, 162, 235, 0.8)",
            "rgba(255, 206, 86, 0.8)",
            "rgba(75, 192, 192, 0.8)",
          ],
          spanGaps: true,
        },
      ],
    },
  });
}
createCoursesChart(){
  this.coursesCharts = new Chart(this.courses.nativeElement, {
    type:  this.type,
    options: {
      responsive: true,
      maintainAspectRatio: true,
      title: {
        display: true,
        text: "Courses Overview",
      },
      scales: {
        yAxes: [{
          display: true,
          scaleLabel: {
              display: true,
              // labelString: 'Score'
          },
      }],
      },
    },
    data: { labels: [
      'East 1', 'East 2','West'
    ],
      datasets: [
        {
          fill: true,
          type: this.type,
          label: "Courses",
          data:[100, 60, 40],
          backgroundColor: [
        
            "rgba(255, 99, 132, 0.8)",
            "rgba(54, 162, 235, 0.8)",
            "rgba(255, 206, 86, 0.8)",
          
          ],
          spanGaps: true,
        },
      ],
    },
  });
}

  bookingChart(){
    this.bookingchart = new Chart(this.doughnutCanvas.nativeElement, {
      type: this.type,
      options: {
        responsive: true,
        title: {
          display: true,
          text: "Booking Future/Slots",
        },
        scales: {
          yAxes: [
            {
              ticks: {
                beginAtZero: true,
              },
            },
          ],
        },
      },
      data: { labels: [
        'Morning', 'Afternoon'
      ],
        datasets: [
          {
            fill: true,
            type: this.type,
            label: "Bookings",
            data:[60, 40],
            backgroundColor: [
              "rgba(153, 102, 255, 0.3)",
              "rgba(255, 99, 132, 0.2)",
              
            ],
            spanGaps: true,
          },
        ],
      },
    });
  }

  createChart() {
    this.barChart = new Chart(this.barCanvas.nativeElement, {
      type: this.type,
      options: {
        responsive: true,
        title: {
          display: true,
          text: "Club Statistical Analysis ",
        },
        scales: {
          yAxes: [
            {
              ticks: {
                beginAtZero: true,
              },
            },
          ],
          //   xAxes: [{
          //     type: 'time',
          //     time: {
          //         displayFormats: {
          //             quarter: 'MMM YYYY'
          //         },
          //     },
          //     distribution: 'series'
          // }],
        },
      },
      data: {
        labels: [
          "Jan",
          "Feb",
          "Mar",
          "April",
          "May",
          "June",
          "July",
          "Aug",
          "Sep",
          "Oct",
          "Nov",
          "Dec",
        ],
        datasets: [
          {
            showLine: true,
            fill: true,
            type: this.type,
            label: "Club",
            data: this.chartData.dataSet1,
            backgroundColor: [
              "rgba(153, 102, 255, 0.3)",
              "rgba(255, 99, 132, 0.2)",
              "rgba(54, 162, 235, 0.2)",
              "rgba(255, 206, 86, 0.2)",
              "rgba(75, 192, 192, 0.2)",
              "rgba(153, 102, 255, 0.2)",
              "rgba(255, 159, 64, 0.2)",
            ],
            borderColor: "rgba(153, 102, 255, 0.3)",
            lineTension: 0.1,
            borderCapStyle: "butt",
            borderDash: [],
            borderDashOffset: 0.0,
            borderJoinStyle: "miter",
            pointBorderColor: "rgba(75,192,192,1)",
            pointBackgroundColor: "#fff",
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBackgroundColor: "rgba(75,192,192,1)",
            pointHoverBorderColor: "rgba(220,220,220,1)",
            pointHoverBorderWidth: 2,
            pointRadius: 1,
            pointHitRadius: 10,
            spanGaps: true,
          },
        ],
      },
    });
  }

  thisMonthData() {}

  thisWeekData() {
    let outOfWeek = new Date();
    outOfWeek.setDate(outOfWeek.getDate() + 7);

    const dateList = [new Date(), outOfWeek];
    const monthDay = new Date().getDate();
    const weekDay = new Date().getDay();
    const daysToSunday = 7 + weekDay;
    const daysFromSunday = weekDay;

    const setDateToMidnight = (date) => {
      date.setHours(0);
      date.setMinutes(0);
      date.setSeconds(0);
      date.setMilliseconds(0);
    };

    let maxDate = new Date();
    maxDate.setDate(monthDay + daysToSunday);
    setDateToMidnight(maxDate);

    let minDate = new Date();
    minDate.setDate(monthDay - daysFromSunday);
    setDateToMidnight(minDate);

    let filteredDates = dateList.filter((date) => {
      if (
        date.getTime() < maxDate.getTime() &&
        date.getTime() >= minDate.getTime()
      ) {
        return true;
      } else {
        return false;
      }
    });

    console.log("datelist", dateList);
    console.log("filterdates", filteredDates);
    let newDtae = dateList.map((x) => {
      let date = x.getDate();
      let month = x.getMonth();
      return date + this.levelsArr[month];
    });
    // for (let index = 0; index < dateList.length; index++) {
    //      this.thisweek = dateList[index].getUTCDate();
    // }
    // console.log('week',this.thisweek)
    this.barChart.data.labels = newDtae;
    this.barChart.update();
  }

  todayData() {
    let outOfWeek = new Date();
    outOfWeek.setDate(outOfWeek.getDate() + 7);

    const dateList = [new Date(), outOfWeek];
    const monthDay = new Date().getDate();
    const weekDay = new Date().getDay();
    const daysToSunday = 7 - weekDay;
    const daysFromSunday = weekDay;

    const setDateToMidnight = (date) => {
      date.setHours(0);
      date.setMinutes(0);
      date.setSeconds(0);
      date.setMilliseconds(0);
    };

    let maxDate = new Date();
    maxDate.setDate(monthDay + daysToSunday);
    setDateToMidnight(maxDate);

    let minDate = new Date();
    minDate.setDate(monthDay - daysFromSunday);
    setDateToMidnight(minDate);

    let filteredDates = dateList.filter((date) => {
      if (
        date.getTime() < maxDate.getTime() &&
        date.getTime() >= minDate.getTime()
      ) {
        return true;
      } else {
        return false;
      }
    });
    let newDtae = filteredDates.map((x) => {
      let date = x.getDate();
      let month = x.getMonth();
      return date + this.levelsArr[month];
    });
    this.barChart.data.labels = newDtae;
    this.barChart.update();
  }

  select() {
    this.barChart.destroy();
    this.createChart();
    this.Pax.destroy();
    this.createtotalpaxChart();
    this.bookingchart.destroy();
    this.bookingChart();
    this.coursesCharts.destroy();
    this.createCoursesChart();
    this.caddiesChart.destroy();
    this.createCaddiesChart();

  }

  removeData(chart) {
    this.doughnutChart.data.labels.pop();
    this.doughnutChart.data.datasets.forEach((dataset) => {
      dataset.data.pop();
    });
    chart.update();
  }

  updateChartData(chart, data, dataSetIndex) {
    chart.data.datasets[dataSetIndex].data = data;
    chart.update();
  }

  applyFilter(value) {
    console.log(this.chartData.dataSet1);
    this.barChart.data.datasets[0].data = this.chartData.dataSet1;
    // this.barChart.data.datasets[1].data = this.chartData.dataSet2;

    this.barChart.data.datasets.forEach((data, i) => {
      if (this.lessThanOrGreaterThan === "greaterThan") {
        this.barChart.data.datasets[i].data = data.data.map((v) => {
          if (v >= value) return v;
          else return 0;
        });
        console.log(">>>>>>>>", this.barChart.data.datasets[i].data);
      } else {
        this.barChart.data.datasets[i].data = data.data.map((v) => {
          if (v <= value) return v;
          else return 0;
        });
        console.log("?????????", this.barChart.data.datasets[i].data);
      }
    });
    this.barChart.update();
  }

  applyDateFilter(start: any, end: any) {
    this.barChart.data.labels = this.levelsArr.slice(
      parseInt(this.from),
      parseInt(this.toMonth) + 1
    );
    this.barChart.update();
  }
}
